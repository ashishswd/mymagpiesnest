frameworkShortcodeAtts={
	attributes:[
			{
				label:"Google map link",
				id:"src",
				help:"Embed code to location."
			},
			{
				label:"Width",
				id:"width",
				help:"Set width for your map."
			},
			{
				label:"Height",
				id:"height",
				help:"Set height for your map."
			}
	],
	defaultContent:"",
	shortcode:"map"
};